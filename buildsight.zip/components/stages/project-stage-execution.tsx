"use client"

import Link from "next/link"
import { useMemo, useState } from "react"
import {
  ChevronDown,
  ChevronRight,
  ClipboardCheck,
  Eye,
  FileCheck2,
  FileText,
  Plus,
} from "lucide-react"
import { Badge } from "@/components/ui/badge"
import { buttonVariants } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { ManageProjectStagesButton } from "@/components/stages/project-stage-admin-controls"
import type { ProjectStageExecutionData } from "@/lib/db/project-stages"
import { statusLabel, statusTone } from "@/lib/stages/execution"
import { cn } from "@/lib/utils"
import { useI18n } from "@/lib/i18n"

const COPY = {
  en: {
    title: "Visit Reports",
    subtitle: "Track construction lifecycle reports, progress, and inspection details.",
    noStages: "No active project stages are available.",
    noStagesHint: "An administrator can activate the construction stages used by this project.",
    noReports: "No inspection reports have been registered for this stage yet.",
    addReport: "Add Report",
    reports: "Reports",
    viewReport: "View / Edit Report",
  },
  ar: {
    title: "تقارير المعاينة",
    subtitle: "متابعة تقارير دورة حياة الإنشاء وسير العمل ونسب الإنجاز.",
    noStages: "لا توجد مراحل نشطة لهذا المشروع.",
    noStagesHint: "يمكن للمسؤول تفعيل مراحل الإنشاء المستخدمة في هذا المشروع.",
    noReports: "لم يتم تسجيل أي تقارير معاينة لهذه المرحلة بعد.",
    addReport: "إضافة تقرير",
    reports: "التقارير",
    viewReport: "عرض / تعديل التقرير",
  },
} as const

function formatDate(value: string, locale: "en" | "ar") {
  const date = new Date(value)
  return new Intl.DateTimeFormat(locale === "ar" ? "ar" : "en-GB", { day: "2-digit", month: "short", year: "numeric" }).format(date)
}

export function ProjectStageExecutionView({ data }: { data: ProjectStageExecutionData }) {
  const { locale } = useI18n()
  const language: "en" | "ar" = locale === "ar" ? "ar" : "en"
  const copy = COPY[language]
  const [openStages, setOpenStages] = useState<Set<string>>(() => new Set(data.stages.slice(0, 2).map((stage) => stage.id)))

  const totals = useMemo(() => {
    let totalItems = 0
    let checkedItems = 0

    for (const stage of data.stages) {
      const reportsMap = new Map<string, any>()
      for (const term of stage.terms ?? []) {
        const responses = term.responses ?? (term.response ? [term.response] : [])
        for (const resp of responses) {
          if (!reportsMap.has(resp.id)) reportsMap.set(resp.id, resp)
        }
      }
      for (const report of stage.reports ?? []) {
        if (!reportsMap.has(report.id)) reportsMap.set(report.id, report)
      }
      for (const report of reportsMap.values()) {
        const checklist = report.content?.checklist ?? []
        for (const item of checklist) {
          totalItems++
          if (item.checked || item.result === "pass") {
            checkedItems++
          }
        }
      }
    }

    const percentage = totalItems > 0 ? Math.round((checkedItems / totalItems) * 100) : 0
    return { total: totalItems, completed: checkedItems, percentage }
  }, [data.stages])

  return (
    <div className="mx-auto flex w-full max-w-7xl flex-col gap-6">
      <div className="flex flex-col gap-4 rounded-2xl border bg-card p-5 shadow-sm sm:p-6 lg:flex-row lg:items-center lg:justify-between">
        <div className="min-w-0">
          <div className="mb-2 flex items-center gap-2 text-sm font-semibold text-primary">
            <ClipboardCheck className="size-4" />
            <span className="truncate">{data.project.name}</span>
          </div>
          <div className="flex flex-wrap items-center gap-3">
            <h1 className="text-2xl font-semibold tracking-tight sm:text-3xl">{copy.title}</h1>
            {data.canManage ? <ManageProjectStagesButton projectId={data.project.id} stages={data.availableStages} /> : null}
          </div>
          <p className="mt-1 text-sm text-muted-foreground">{copy.subtitle}</p>
        </div>
        <div className="grid min-w-0 grid-cols-3 gap-2 sm:min-w-[270px] sm:gap-3">
          <Metric value={totals.total} label={language === "ar" ? "بنود الفحص" : "Checklist Items"} />
          <Metric value={totals.completed} label={language === "ar" ? "تم فحصها" : "Checked"} />
          <Metric value={`${totals.percentage}%`} label={language === "ar" ? "نسبة الإنجاز" : "Progress"} />
        </div>
      </div>

      {data.stages.length === 0 ? (
        <Card>
          <CardContent className="flex min-h-64 flex-col items-center justify-center text-center">
            <FileCheck2 className="mb-4 size-10 text-muted-foreground" />
            <h2 className="font-semibold">{copy.noStages}</h2>
            <p className="mt-2 max-w-xl text-sm text-muted-foreground">{copy.noStagesHint}</p>
            {data.canManage ? <div className="mt-4"><ManageProjectStagesButton projectId={data.project.id} stages={data.availableStages} /></div> : null}
          </CardContent>
        </Card>
      ) : (
        <div className="flex flex-col gap-4">
          {data.stages.map((stage) => {
            const open = openStages.has(stage.id)
            const cleanStageName = stage.name.replace(/^\d+[\.\s\-]+/, "")

            const stageReportsMap = new Map<string, any>()
            for (const term of stage.terms ?? []) {
              const responses = term.responses ?? (term.response ? [term.response] : [])
              for (const resp of responses) {
                if (!stageReportsMap.has(resp.id)) {
                  stageReportsMap.set(resp.id, resp)
                }
              }
            }
            for (const report of stage.reports ?? []) {
              if (!stageReportsMap.has(report.id)) {
                stageReportsMap.set(report.id, report)
              }
            }
            const stageReports = Array.from(stageReportsMap.values())

            let stageTotalCheckboxes = 0
            let stageCheckedCheckboxes = 0

            for (const report of stageReports) {
              const checklist = report.content?.checklist ?? []
              for (const item of checklist) {
                stageTotalCheckboxes++
                if (item.checked || item.result === "pass") {
                  stageCheckedCheckboxes++
                }
              }
            }

            const stageCheckboxPercentage = stageTotalCheckboxes > 0 ? Math.round((stageCheckedCheckboxes / stageTotalCheckboxes) * 100) : 0

            return (
              <Card key={stage.id} className="gap-0 overflow-hidden py-0">
                <CardHeader className="border-b px-4 py-3.5 sm:px-5">
                  <div className="flex w-full items-center justify-between gap-4">
                    <button
                      type="button"
                      aria-expanded={open}
                      onClick={() => setOpenStages((current) => {
                        const next = new Set(current)
                        if (next.has(stage.id)) next.delete(stage.id)
                        else next.add(stage.id)
                        return next
                      })}
                      className="flex min-w-0 flex-1 items-center gap-3 text-start"
                    >
                      <span className="flex size-7 shrink-0 items-center justify-center rounded-lg bg-primary/10 text-primary">
                        {open ? <ChevronDown className="size-4" /> : <ChevronRight className="size-4 flip-rtl" />}
                      </span>
                      <CardTitle className="truncate text-base font-semibold text-foreground">{cleanStageName}</CardTitle>
                      <span className="text-xs text-muted-foreground whitespace-nowrap">({stageReports.length} {copy.reports})</span>
                    </button>

                    <div className="flex items-center gap-3 shrink-0">
                      <span className="text-xs font-medium tabular-nums text-muted-foreground whitespace-nowrap">
                        {stageCheckedCheckboxes} / {stageTotalCheckboxes} ({stageCheckboxPercentage}%)
                      </span>
                      <Link
                        href={`/projects/${data.project.id}/stages/${stage.id}/reports/new`}
                        className={cn(buttonVariants({ variant: "outline", size: "sm" }), "h-8 gap-1.5 px-3 text-xs font-medium shrink-0")}
                        onClick={(e) => e.stopPropagation()}
                      >
                        <Plus className="size-3.5" />
                        {copy.addReport}
                      </Link>
                    </div>
                  </div>
                </CardHeader>

                {open ? (
                  <CardContent className="p-0">
                    {stageReports.length ? (
                      <div className="divide-y">
                        {stageReports.map((report) => (
                          <div key={report.id} className="flex flex-wrap items-center justify-between gap-3 p-4 transition-colors hover:bg-muted/30">
                            <div className="flex min-w-0 items-center gap-3">
                              <FileText className="size-4 text-muted-foreground shrink-0" />
                              <div className="min-w-0">
                                <div className="flex flex-wrap items-center gap-2">
                                  <span className="font-semibold text-sm text-foreground">{report.reportTitle || report.reportNumber}</span>
                                  <Badge variant="outline" className={cn("text-[11px]", statusTone(report.status))}>
                                    {statusLabel(report.status, language)}
                                  </Badge>
                                </div>
                                <p className="mt-0.5 flex items-center gap-2 text-xs text-muted-foreground">
                                  <span>{report.reportNumber}</span>
                                  <span>•</span>
                                  <span>{language === "ar" ? `زيارة #${report.visitNumber}` : `Visit #${report.visitNumber}`}</span>
                                  {report.createdBy?.name ? (
                                    <>
                                      <span>•</span>
                                      <span>{report.createdBy.name}</span>
                                    </>
                                  ) : null}
                                  <span>•</span>
                                  <span>{formatDate(report.createdAt, language)}</span>
                                </p>
                              </div>
                            </div>
                            <Link
                              href={`/projects/${data.project.id}/stages/${stage.id}/reports/${report.id}`}
                              className={cn(buttonVariants({ variant: "ghost", size: "sm" }), "h-8 gap-1 text-xs text-primary font-medium")}
                            >
                              <Eye className="size-3.5" />
                              {copy.viewReport}
                            </Link>
                          </div>
                        ))}
                      </div>
                    ) : (
                      <p className="p-6 text-center text-sm text-muted-foreground">{copy.noReports}</p>
                    )}
                  </CardContent>
                ) : null}
              </Card>
            )
          })}
        </div>
      )}
    </div>
  )
}

function Metric({ value, label }: { value: number | string; label: string }) {
  return (
    <div className="rounded-xl border bg-muted/25 px-2 py-3 text-center sm:px-3">
      <div className="text-lg font-semibold tabular-nums sm:text-xl">{value}</div>
      <div className="mt-0.5 text-[11px] text-muted-foreground">{label}</div>
    </div>
  )
}
